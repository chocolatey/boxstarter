function Get-BoxstarterTempDir {
    if(!(test-path "$env:LocalAppData\Boxstarter")){mkdir "$env:LocalAppData\Boxstarter" | out-null}
    return "$env:LocalAppData\Boxstarter"
}