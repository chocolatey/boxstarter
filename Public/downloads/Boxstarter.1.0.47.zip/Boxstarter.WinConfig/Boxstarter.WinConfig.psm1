Resolve-Path $PSScriptRoot\*.ps1 | 
    % { . $_.ProviderPath }

Export-ModuleMember Disable-UAC, `
                    Enable-UAC, `
                    Get-UAC, `
                    Disable-InternetExplorerESC, `
                    Get-ExplorerOptions, `
                    Set-TaskbarSmall, `
                    Install-WindowsUpdate, `
                    Move-LibraryDirectory, `
                    Enable-RemoteDesktop, `
                    Set-ExplorerOptions, `
                    Get-LibraryNames, `
                    Update-ExecutionPolicy
