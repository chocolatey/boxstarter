function Format-BoxStarterMessage {
    param($BoxStarterMessage)
    #I could put some crazy formatting here...if I wanted to.
    return $BoxStarterMessage
}