using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Boxstarter.WebLaunch")]
[assembly: AssemblyProduct("Boxstarter.WebLaunch")]
[assembly: AssemblyCopyright("(c) 2013 Matt Wrock")]
[assembly: AssemblyTrademark("5e4b3a3055230e49bdc9cbc98a07f21ddac67288")]
[assembly: AssemblyVersion("1.0.43")]
[assembly: AssemblyFileVersion("1.0.43")]
