function Restart-Explorer {
    try{Stop-Process -processname explorer -Force -ErrorAction Stop | Out-Null} catch {}
}
